import logging

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import LoginView
from django.core.exceptions import PermissionDenied, ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import CreateView, ListView, TemplateView, UpdateView

from .forms import CustomUserCreationForm, LoggingAuthenticationForm, ProfileUpdateForm
from .models import CustomUser

logger = logging.getLogger(__name__)


class HomeView(TemplateView):
    template_name = 'home.html'


class CustomLoginView(LoginView):
    """Стандартный вход Django, дополненный логированием успешных и неудачных попыток."""
    template_name = 'registration/login.html'
    authentication_form = LoggingAuthenticationForm

    def form_valid(self, form):
        username = form.cleaned_data.get('username')
        logger.info('User %s logged in successfully', username)
        return super().form_valid(form)

    def form_invalid(self, form):
        username = self.request.POST.get('username', '')
        logger.warning('Failed login attempt for %s. Errors: %s', username, form.errors)
        return super().form_invalid(form)


class RegisterView(CreateView):
    form_class = CustomUserCreationForm
    template_name = 'users/register.html'
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)
        logger.info('New user registered: %s', self.object.username)
        messages.success(self.request, 'Регистрация прошла успешно. Вы вошли в систему.')
        return response

    def form_invalid(self, form):
        logger.warning('Registration validation errors: %s', form.errors)
        return super().form_invalid(form)


class UserListView(LoginRequiredMixin, ListView):
    model = CustomUser
    template_name = 'users/user_list.html'
    context_object_name = 'users_list'
    ordering = ('username',)


class ProfileDetailView(LoginRequiredMixin, TemplateView):
    template_name = 'users/profile_detail.html'

    def dispatch(self, request, *args, **kwargs):
        self.profile_user = get_object_or_404(CustomUser, username=kwargs['username'])
        if self.profile_user != request.user and self.profile_user not in request.user.friends.all():
            logger.warning(
                'User %s tried to open forbidden profile %s',
                request.user.username,
                self.profile_user.username,
            )
            raise PermissionDenied('Нельзя просматривать профили незнакомых пользователей.')
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['profile_user'] = self.profile_user
        context['is_self'] = self.request.user == self.profile_user
        context['is_friend'] = self.profile_user in self.request.user.friends.all()
        return context


class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = CustomUser
    form_class = ProfileUpdateForm
    template_name = 'users/profile_edit.html'

    def get_object(self, queryset=None):
        return self.request.user

    def get_success_url(self):
        return reverse_lazy('profile_detail', kwargs={'username': self.request.user.username})

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
        except (ValidationError, OSError, ValueError) as exc:
            logger.exception(
                'Avatar upload/update error for user %s: %s',
                self.request.user.username,
                exc,
                exc_info=True,
            )
            raise

        logger.info('User %s updated profile', self.request.user.username)
        messages.success(self.request, 'Профиль обновлен.')
        return response

    def form_invalid(self, form):
        if self.request.FILES.get('avatar'):
            logger.warning(
                'Profile update with invalid avatar/data for user %s. Errors: %s',
                self.request.user.username,
                form.errors,
            )
        return super().form_invalid(form)


class AddFriendView(LoginRequiredMixin, View):
    def post(self, request, username):
        friend = get_object_or_404(CustomUser, username=username)
        if friend == request.user:
            logger.warning('User %s tried to add themselves as friend', request.user.username)
            messages.error(request, 'Нельзя добавить в друзья самого себя.')
            return redirect('profile_detail', username=username)

        request.user.friends.add(friend)
        logger.info('User %s added user %s to friends', request.user.username, friend.username)
        messages.success(request, f'Пользователь {friend.username} добавлен в друзья.')
        return redirect('profile_detail', username=username)


class RemoveFriendView(LoginRequiredMixin, View):
    def post(self, request, username):
        friend = get_object_or_404(CustomUser, username=username)
        request.user.friends.remove(friend)
        logger.info('User %s removed user %s from friends', request.user.username, friend.username)
        messages.success(request, f'Пользователь {friend.username} удалён из друзей.')
        return redirect('profile_detail', username=username)


def permission_denied_view(request, exception=None):
    return render(request, '403.html', status=403)
