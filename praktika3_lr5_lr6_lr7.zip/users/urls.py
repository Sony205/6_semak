from django.urls import path

from .views import (
    AddFriendView,
    ProfileDetailView,
    ProfileUpdateView,
    RegisterView,
    RemoveFriendView,
    UserListView,
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('', UserListView.as_view(), name='user_list'),
    path('profile/edit/', ProfileUpdateView.as_view(), name='profile_edit'),
    path('profile/<str:username>/', ProfileDetailView.as_view(), name='profile_detail'),
    path('profile/<str:username>/add-friend/', AddFriendView.as_view(), name='add_friend'),
    path('profile/<str:username>/remove-friend/', RemoveFriendView.as_view(), name='remove_friend'),
]
