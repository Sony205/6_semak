# Лабораторная работа 7. Логирование

Что добавлено:

1. Логирование через `LOGGING` в `config/settings.py`.
2. Логгер в `users/views.py`: `logger = logging.getLogger(__name__)`.
3. Хэндлеры:
   - консольный `StreamHandler`;
   - файл с ротацией `RotatingFileHandler`;
   - файл с ежедневной ротацией `TimedRotatingFileHandler`, хранение 7 дней.
4. Логирование:
   - успешный вход — INFO;
   - неудачный вход — WARNING;
   - успешная регистрация — INFO;
   - ошибки регистрации — WARNING;
   - добавление друга — INFO;
   - удаление друга — INFO;
   - попытка открыть чужой закрытый профиль — WARNING;
   - ошибки загрузки/обновления аватара — logger.exception(..., exc_info=True).
5. Добавлена аватарка пользователя через `ImageField`.
6. Добавлены `MEDIA_URL`, `MEDIA_ROOT` и раздача media-файлов в режиме DEBUG.
7. Добавлена страница `403.html`.

Как запустить:

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Где смотреть логи:

```text
logs/project.log
logs/daily.log
```
