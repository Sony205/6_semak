import logging

from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from PIL import Image, UnidentifiedImageError
import re

from .models import CustomUser

logger = logging.getLogger(__name__)


ALLOWED_EMAIL_ZONES = {
    'ru', 'com', 'org', 'net', 'edu', 'gov', 'info', 'biz', 'io', 'su', 'рф'
}


class LoggingAuthenticationForm(AuthenticationForm):
    """Форма входа вынесена отдельно, чтобы во view можно было логировать ошибки авторизации."""
    pass


class ContactValidationMixin:
    def clean_email(self):
        email = (self.cleaned_data.get('email') or '').strip().lower()
        if not email:
            self.cleaned_data['email'] = ''
            raise ValidationError('Введите email.')

        if '@' not in email:
            self.cleaned_data['email'] = ''
            raise ValidationError('Email должен содержать символ @.')

        local_part, domain = email.rsplit('@', 1)
        if not local_part:
            self.cleaned_data['email'] = ''
            raise ValidationError('До символа @ должна быть указана почта пользователя.')
        if '.' not in domain:
            self.cleaned_data['email'] = ''
            raise ValidationError('После @ должен быть указан домен, например mail.ru.')

        try:
            validate_email(email)
        except ValidationError:
            self.cleaned_data['email'] = ''
            raise ValidationError('Введите правильный адрес электронной почты.')

        zone = domain.rsplit('.', 1)[-1]
        if zone not in ALLOWED_EMAIL_ZONES:
            self.cleaned_data['email'] = ''
            raise ValidationError(
                'Недопустимая доменная зона email. Используйте адрес вида name@mail.ru, name@gmail.com и т.д.'
            )

        return email

    def clean_phone(self):
        phone = (self.cleaned_data.get('phone') or '').strip()
        if not phone:
            raise ValidationError('Введите номер телефона.')

        if re.search(r'[A-Za-zА-Яа-яЁё]', phone):
            raise ValidationError('Телефон не должен содержать буквы.')

        digits = phone[1:] if phone.startswith('+') else phone

        if not digits.isdigit():
            raise ValidationError('Телефон должен содержать только цифры.')

        if len(digits) != 11:
            raise ValidationError('Телефон должен содержать ровно 11 цифр.')

        if digits[0] not in {'7', '8'}:
            raise ValidationError('Телефон должен начинаться с +7, 7 или 8.')

        return phone


    def clean_avatar(self):
        avatar = self.cleaned_data.get('avatar')
        if not avatar:
            return avatar

        try:
            image = Image.open(avatar)
            image.verify()
            avatar.seek(0)
        except (UnidentifiedImageError, OSError, ValueError) as exc:
            logger.exception('Invalid avatar file uploaded: %s', exc, exc_info=True)
            raise ValidationError('Загруженный файл не является изображением.')

        return avatar


class CustomUserCreationForm(ContactValidationMixin, UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'middle_name', 'email', 'phone')
        widgets = {
            'username': forms.TextInput(attrs={'placeholder': 'login123'}),
            'first_name': forms.TextInput(attrs={'placeholder': 'Иван'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Иванов'}),
            'middle_name': forms.TextInput(attrs={'placeholder': 'Иванович'}),
            'email': forms.EmailInput(attrs={'placeholder': 'name@mail.ru'}),
            'phone': forms.TextInput(attrs={'placeholder': '+79991234567'}),
        }
        help_texts = {
            'email': 'Введите корректный email, например name@mail.ru или name@gmail.com.',
            'phone': 'Введите номер в формате +79991234567, 79991234567 или 89991234567.',
        }


class ProfileUpdateForm(ContactValidationMixin, forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name', 'middle_name', 'email', 'phone', 'avatar')
        widgets = {
            'first_name': forms.TextInput(attrs={'placeholder': 'Иван'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Иванов'}),
            'middle_name': forms.TextInput(attrs={'placeholder': 'Иванович'}),
            'email': forms.EmailInput(attrs={'placeholder': 'name@mail.ru'}),
            'phone': forms.TextInput(attrs={'placeholder': '+79991234567'}),
        }
        help_texts = {
            'email': 'Разрешены адреса с доменами .ru, .com, .org, .net, .edu, .gov, .info, .biz, .io, .su, .рф.',
            'phone': 'Телефон должен содержать ровно 11 цифр и начинаться с +7, 7 или 8.',
            'avatar': 'Загрузите изображение профиля.',
        }
